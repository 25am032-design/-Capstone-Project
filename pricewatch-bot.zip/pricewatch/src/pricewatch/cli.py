"""Command line interface (argparse)."""

from __future__ import annotations

import argparse
import logging
import logging.handlers
import signal
import sys
from collections.abc import Sequence
from pathlib import Path

from pricewatch import __version__
from pricewatch.config import DEFAULT_HOME, SAMPLE_CONFIG, Config, load_config
from pricewatch.engine import AlertEngine
from pricewatch.models import ASSET_TYPES, Alert
from pricewatch.notifiers import ConsoleNotifier, build_notifiers
from pricewatch.providers import ProviderError, build_providers
from pricewatch.scheduler import Scheduler
from pricewatch.storage import Storage

log = logging.getLogger("pricewatch")


# --------------------------------------------------------------------------- parser
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pricewatch",
        description="Real-time crypto & stock price alert bot.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("-c", "--config", help="path to a TOML config file")
    parser.add_argument("--db", help="path to the SQLite database (overrides config)")
    parser.add_argument("--mock", action="store_true", help="use the simulated offline price feed")
    parser.add_argument("-v", "--verbose", action="count", default=0, help="-v for DEBUG logging")

    sub = parser.add_subparsers(dest="command", required=True, metavar="<command>")

    p = sub.add_parser("init", help="write a sample config file")
    p.add_argument("--path", help=f"destination (default: {DEFAULT_HOME / 'config.toml'})")
    p.add_argument("--force", action="store_true", help="overwrite an existing file")

    p = sub.add_parser("add", help="create a price alert")
    p.add_argument("symbol", help="ticker, e.g. BTC, ETH, AAPL, TSLA")
    p.add_argument("-t", "--type", dest="asset_type", choices=ASSET_TYPES, default="crypto")
    rule = p.add_mutually_exclusive_group(required=True)
    rule.add_argument("--above", type=float, metavar="PRICE", help="alert when price >= PRICE")
    rule.add_argument("--below", type=float, metavar="PRICE", help="alert when price <= PRICE")
    rule.add_argument("--rise", type=float, metavar="PCT", help="alert on a rise of PCT%% in the window")
    rule.add_argument("--drop", type=float, metavar="PCT", help="alert on a drop of PCT%% in the window")
    p.add_argument("--window", type=int, default=60, metavar="MIN", help="window for --rise/--drop (default 60)")
    p.add_argument("--cooldown", type=int, default=60, metavar="MIN", help="minutes between repeat alerts (default 60)")

    p = sub.add_parser("list", help="list alerts")
    p.add_argument("--all", action="store_true", help="include paused alerts")

    p = sub.add_parser("remove", help="delete an alert")
    p.add_argument("id", type=int)

    p = sub.add_parser("pause", help="pause an alert")
    p.add_argument("id", type=int)

    p = sub.add_parser("resume", help="resume a paused alert")
    p.add_argument("id", type=int)

    p = sub.add_parser("price", help="fetch the current price of a symbol")
    p.add_argument("symbol")
    p.add_argument("-t", "--type", dest="asset_type", choices=ASSET_TYPES, default="crypto")

    sub.add_parser("check", help="run a single check cycle and exit")

    p = sub.add_parser("run", help="run continuously on a schedule")
    p.add_argument("-i", "--interval", type=int, help="seconds between checks (overrides config)")
    p.add_argument("--max-runs", type=int, help="stop after N cycles (useful for demos/tests)")

    p = sub.add_parser("history", help="show recorded prices for a symbol")
    p.add_argument("symbol")
    p.add_argument("-n", "--limit", type=int, default=15)

    p = sub.add_parser("events", help="show recently fired alerts")
    p.add_argument("-n", "--limit", type=int, default=15)

    sub.add_parser("test-notify", help="send a test notification through all enabled channels")
    return parser


# --------------------------------------------------------------------------- helpers
def setup_logging(cfg: Config, verbose: int) -> None:
    level = logging.DEBUG if verbose else getattr(logging, cfg.log_level, logging.INFO)
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stderr)]
    if cfg.log_file:
        cfg.log_file.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(
            logging.handlers.RotatingFileHandler(cfg.log_file, maxBytes=1_000_000, backupCount=3)
        )
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
        force=True,
    )
    logging.getLogger("urllib3").setLevel(logging.WARNING)


def table(headers: Sequence[str], rows: Sequence[Sequence[object]]) -> str:
    cells = [[str(c) for c in row] for row in rows]
    widths = [max(len(h), *(len(r[i]) for r in cells)) if cells else len(h) for i, h in enumerate(headers)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    lines = [fmt.format(*headers), fmt.format(*("-" * w for w in widths))]
    lines += [fmt.format(*r) for r in cells]
    return "\n".join(lines)


def _fmt_dt(dt) -> str:
    return dt.astimezone().strftime("%Y-%m-%d %H:%M:%S") if dt else "-"


# --------------------------------------------------------------------------- commands
def cmd_init(args: argparse.Namespace, cfg: Config) -> int:
    path = Path(args.path).expanduser() if args.path else DEFAULT_HOME / "config.toml"
    if path.exists() and not args.force:
        print(f"{path} already exists (use --force to overwrite)", file=sys.stderr)
        return 1
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(SAMPLE_CONFIG, encoding="utf-8")
    print(f"Wrote sample config to {path}")
    return 0


def cmd_add(args: argparse.Namespace, cfg: Config) -> int:
    for cond in ("above", "below", "rise", "drop"):
        value = getattr(args, cond)
        if value is not None:
            condition, threshold = cond, value
            break
    try:
        alert = Alert(
            symbol=args.symbol,
            asset_type=args.asset_type,
            condition=condition,
            threshold=threshold,
            window_minutes=args.window,
            cooldown_minutes=args.cooldown,
        )
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    with Storage(cfg.db_path) as db:
        db.add_alert(alert)
    print(f"Created alert #{alert.id}: {alert.describe()} (cooldown {alert.cooldown_minutes} min)")
    return 0


def cmd_list(args: argparse.Namespace, cfg: Config) -> int:
    with Storage(cfg.db_path) as db:
        alerts = db.list_alerts(active_only=not args.all)
    if not alerts:
        print("No alerts yet. Create one with: pricewatch add BTC --above 100000")
        return 0
    rows = [
        (a.id, a.asset_type, a.symbol, a.describe(), "active" if a.active else "paused", _fmt_dt(a.last_triggered))
        for a in alerts
    ]
    print(table(("ID", "TYPE", "SYMBOL", "RULE", "STATUS", "LAST TRIGGERED"), rows))
    return 0


def _simple_alert_op(args: argparse.Namespace, cfg: Config, op: str) -> int:
    with Storage(cfg.db_path) as db:
        if op == "remove":
            ok = db.remove_alert(args.id)
        else:
            ok = db.set_active(args.id, op == "resume")
    if not ok:
        print(f"error: no alert with id {args.id}", file=sys.stderr)
        return 1
    print(f"Alert #{args.id}: {op}d" if op != "pause" else f"Alert #{args.id}: paused")
    return 0


def cmd_price(args: argparse.Namespace, cfg: Config) -> int:
    provider = build_providers(cfg.mock)[args.asset_type]
    try:
        quotes = provider.fetch([args.symbol])
    except ProviderError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    quote = quotes.get(args.symbol.upper())
    if not quote:
        print(f"error: no price found for {args.symbol.upper()} ({args.asset_type})", file=sys.stderr)
        return 1
    print(f"{quote.symbol}: {quote.price:,.2f} {quote.currency}  [{quote.source}]")
    return 0


def _make_engine(cfg: Config, db: Storage) -> AlertEngine:
    return AlertEngine(
        db,
        build_providers(cfg.mock),
        build_notifiers(cfg.notifiers),
        retention_days=cfg.retention_days,
    )


def cmd_check(args: argparse.Namespace, cfg: Config) -> int:
    with Storage(cfg.db_path) as db:
        result = _make_engine(cfg, db).run_cycle()
    print(
        f"Checked {result.alerts_checked} alert(s), fetched {result.quotes_fetched} price(s), "
        f"{result.alerts_triggered} triggered."
    )
    return 1 if result.errors else 0


def cmd_run(args: argparse.Namespace, cfg: Config) -> int:
    interval = args.interval or cfg.interval_seconds
    with Storage(cfg.db_path) as db:
        engine = _make_engine(cfg, db)

        def job() -> None:
            res = engine.run_cycle()
            log.info(
                "cycle done: %d price(s), %d alert(s) checked, %d triggered, %d error(s)",
                res.quotes_fetched,
                res.alerts_checked,
                res.alerts_triggered,
                len(res.errors),
            )

        scheduler = Scheduler(job, interval, max_runs=args.max_runs)

        def _shutdown(signum, _frame) -> None:
            log.info("received signal %s - shutting down", signal.Signals(signum).name)
            scheduler.stop()

        signal.signal(signal.SIGINT, _shutdown)
        signal.signal(signal.SIGTERM, _shutdown)

        log.info("pricewatch started (interval=%ss, mock=%s). Press Ctrl+C to stop.", interval, cfg.mock)
        scheduler.start()
        log.info("pricewatch stopped after %d cycle(s)", scheduler.runs)
    return 0


def cmd_history(args: argparse.Namespace, cfg: Config) -> int:
    with Storage(cfg.db_path) as db:
        quotes = db.price_history(args.symbol, limit=args.limit)
    if not quotes:
        print(f"No recorded prices for {args.symbol.upper()} yet.")
        return 0
    rows = [
        (_fmt_dt(q.timestamp), q.symbol, q.asset_type, f"{q.price:,.2f}", q.currency, q.source)
        for q in quotes
    ]
    print(table(("TIME", "SYMBOL", "TYPE", "PRICE", "CUR", "SOURCE"), rows))
    return 0


def cmd_events(args: argparse.Namespace, cfg: Config) -> int:
    from datetime import datetime

    with Storage(cfg.db_path) as db:
        events = db.list_events(args.limit)
    if not events:
        print("No alerts have fired yet.")
        return 0
    rows = [(_fmt_dt(datetime.fromisoformat(e["ts"])), e["alert_id"], e["message"]) for e in events]
    print(table(("TIME", "ALERT", "MESSAGE"), rows))
    return 0


def cmd_test_notify(args: argparse.Namespace, cfg: Config) -> int:
    notifiers = build_notifiers(cfg.notifiers) or [ConsoleNotifier()]
    failed = 0
    for n in notifiers:
        try:
            n.send("pricewatch test", "If you can read this, notifications work.")
            print(f"[ok]   {n.name}")
        except Exception as exc:
            failed += 1
            print(f"[fail] {n.name}: {exc}", file=sys.stderr)
    return 1 if failed else 0


COMMANDS = {
    "init": cmd_init,
    "add": cmd_add,
    "list": cmd_list,
    "remove": lambda a, c: _simple_alert_op(a, c, "remove"),
    "pause": lambda a, c: _simple_alert_op(a, c, "pause"),
    "resume": lambda a, c: _simple_alert_op(a, c, "resume"),
    "price": cmd_price,
    "check": cmd_check,
    "run": cmd_run,
    "history": cmd_history,
    "events": cmd_events,
    "test-notify": cmd_test_notify,
}


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        cfg = load_config(args.config)
    except (FileNotFoundError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.db:
        cfg.db_path = Path(args.db).expanduser()
    if args.mock:
        cfg.mock = True
    setup_logging(cfg, args.verbose)
    try:
        return COMMANDS[args.command](args, cfg)
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
