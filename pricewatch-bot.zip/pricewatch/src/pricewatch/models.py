"""Core data models shared across the application."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime

ASSET_TYPES = ("crypto", "stock")
CONDITIONS = ("above", "below", "rise", "drop")


def utcnow() -> datetime:
    """Timezone-aware current UTC time."""
    return datetime.now(UTC)


@dataclass(frozen=True)
class Quote:
    """A single price observation for an asset."""

    symbol: str
    asset_type: str
    price: float
    currency: str
    timestamp: datetime
    source: str


@dataclass
class Alert:
    """A user-defined alert rule.

    Conditions:
      * ``above`` / ``below``: fire when price crosses an absolute threshold.
      * ``rise`` / ``drop``: fire when price moved by ``threshold`` percent
        within the last ``window_minutes`` (relative to the oldest sample in that window).
    """

    symbol: str
    asset_type: str
    condition: str
    threshold: float
    window_minutes: int = 60
    cooldown_minutes: int = 60
    active: bool = True
    id: int | None = None
    last_triggered: datetime | None = None
    created_at: datetime = field(default_factory=utcnow)

    def __post_init__(self) -> None:
        self.symbol = self.symbol.strip().upper()
        if not self.symbol:
            raise ValueError("symbol must not be empty")
        if self.asset_type not in ASSET_TYPES:
            raise ValueError(f"asset_type must be one of {ASSET_TYPES}, got {self.asset_type!r}")
        if self.condition not in CONDITIONS:
            raise ValueError(f"condition must be one of {CONDITIONS}, got {self.condition!r}")
        if self.threshold <= 0:
            raise ValueError("threshold must be greater than 0")
        if self.window_minutes <= 0:
            raise ValueError("window_minutes must be greater than 0")
        if self.cooldown_minutes < 0:
            raise ValueError("cooldown_minutes must not be negative")

    def describe(self) -> str:
        """Human readable summary of the rule."""
        if self.condition == "above":
            return f"{self.symbol} rises above {self.threshold:,.2f}"
        if self.condition == "below":
            return f"{self.symbol} falls below {self.threshold:,.2f}"
        verb = "rises" if self.condition == "rise" else "drops"
        return f"{self.symbol} {verb} by {self.threshold:g}% within {self.window_minutes} min"


@dataclass(frozen=True)
class Trigger:
    """The result of an alert firing."""

    alert: Alert
    quote: Quote
    message: str
