"""Alert evaluation and the check cycle that ties providers, storage and notifiers together."""

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from pricewatch.models import Alert, Quote, Trigger, utcnow
from pricewatch.notifiers import Notifier
from pricewatch.providers import Provider, ProviderError
from pricewatch.storage import Storage

log = logging.getLogger(__name__)


def evaluate_alert(
    alert: Alert, quote: Quote, reference_price: float | None, now: datetime
) -> Trigger | None:
    """Pure function: decide whether ``alert`` fires for ``quote``.

    ``reference_price`` is the oldest price in the alert's window (used for rise/drop).
    Cooldown is enforced here as well so the rule is testable in isolation.
    """
    if not alert.active:
        return None
    if alert.last_triggered and now - alert.last_triggered < timedelta(minutes=alert.cooldown_minutes):
        return None

    price = quote.price
    cur = quote.currency
    message: str | None = None

    if alert.condition == "above" and price >= alert.threshold:
        message = f"{alert.symbol} is above {alert.threshold:,.2f} {cur} (now {price:,.2f} {cur})"
    elif alert.condition == "below" and price <= alert.threshold:
        message = f"{alert.symbol} is below {alert.threshold:,.2f} {cur} (now {price:,.2f} {cur})"
    elif alert.condition in ("rise", "drop") and reference_price:
        change = (price - reference_price) / reference_price * 100
        if alert.condition == "rise" and change >= alert.threshold:
            message = (
                f"{alert.symbol} rose {change:+.2f}% within {alert.window_minutes} min "
                f"({reference_price:,.2f} -> {price:,.2f} {cur})"
            )
        elif alert.condition == "drop" and change <= -alert.threshold:
            message = (
                f"{alert.symbol} dropped {change:+.2f}% within {alert.window_minutes} min "
                f"({reference_price:,.2f} -> {price:,.2f} {cur})"
            )

    return Trigger(alert, quote, message) if message else None


@dataclass
class CycleResult:
    """Summary of one check cycle."""

    quotes_fetched: int = 0
    alerts_checked: int = 0
    alerts_triggered: int = 0
    errors: list[str] = field(default_factory=list)


class AlertEngine:
    def __init__(
        self,
        storage: Storage,
        providers: dict[str, Provider],
        notifiers: list[Notifier],
        *,
        retention_days: int = 30,
        clock: Callable[[], datetime] = utcnow,
    ) -> None:
        self.storage = storage
        self.providers = providers
        self.notifiers = notifiers
        self.retention_days = retention_days
        self.clock = clock

    def run_cycle(self) -> CycleResult:
        """Fetch prices for all active alerts, evaluate them and send notifications."""
        result = CycleResult()
        alerts = self.storage.list_alerts(active_only=True)
        if not alerts:
            log.info("no active alerts - nothing to do")
            return result

        by_type: dict[str, set[str]] = defaultdict(set)
        for alert in alerts:
            by_type[alert.asset_type].add(alert.symbol)

        quotes: dict[tuple[str, str], Quote] = {}
        for asset_type, symbols in by_type.items():
            provider = self.providers.get(asset_type)
            if provider is None:
                result.errors.append(f"no provider for asset type {asset_type!r}")
                continue
            try:
                fetched = provider.fetch(sorted(symbols))
            except ProviderError as exc:
                msg = f"{provider.name}: {exc}"
                log.error("price fetch failed - %s", msg)
                result.errors.append(msg)
                continue
            for sym in symbols - fetched.keys():
                log.warning("no price returned for %s (%s)", sym, asset_type)
                result.errors.append(f"no price for {sym}")
            for sym, quote in fetched.items():
                quotes[(asset_type, sym)] = quote
                self.storage.record_price(quote)
                log.info("%-8s %12s %s  [%s]", sym, f"{quote.price:,.2f}", quote.currency, quote.source)
        result.quotes_fetched = len(quotes)

        now = self.clock()
        for alert in alerts:
            quote = quotes.get((alert.asset_type, alert.symbol))
            if quote is None:
                continue
            result.alerts_checked += 1
            reference = None
            if alert.condition in ("rise", "drop"):
                reference = self.storage.reference_price(
                    alert.symbol,
                    alert.asset_type,
                    since=now - timedelta(minutes=alert.window_minutes),
                    before=quote.timestamp,
                )
            trigger = evaluate_alert(alert, quote, reference, now)
            if trigger:
                result.alerts_triggered += 1
                self._fire(trigger, now)

        self.storage.prune_prices(self.retention_days, now)
        return result

    def _fire(self, trigger: Trigger, now: datetime) -> None:
        alert = trigger.alert
        title = f"Price alert #{alert.id}: {alert.symbol}"
        log.info("ALERT %s", trigger.message)
        self.storage.mark_triggered(alert.id, now)
        self.storage.record_event(alert.id, alert.symbol, trigger.quote.price, trigger.message, now)
        for notifier in self.notifiers:
            try:
                notifier.send(title, trigger.message)
            except Exception as exc:  # one broken channel must not block the others
                log.error("notifier %s failed: %s", notifier.name, exc)
