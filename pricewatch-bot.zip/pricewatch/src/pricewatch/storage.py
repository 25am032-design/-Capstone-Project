"""SQLite persistence for alerts, price history and fired-alert events."""

from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

from pricewatch.models import Alert, Quote, utcnow

SCHEMA = """
CREATE TABLE IF NOT EXISTS alerts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol          TEXT NOT NULL,
    asset_type      TEXT NOT NULL,
    condition       TEXT NOT NULL,
    threshold       REAL NOT NULL,
    window_minutes  INTEGER NOT NULL DEFAULT 60,
    cooldown_minutes INTEGER NOT NULL DEFAULT 60,
    active          INTEGER NOT NULL DEFAULT 1,
    last_triggered  TEXT,
    created_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS prices (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol      TEXT NOT NULL,
    asset_type  TEXT NOT NULL,
    price       REAL NOT NULL,
    currency    TEXT NOT NULL,
    source      TEXT NOT NULL,
    ts          TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_prices_lookup ON prices (symbol, asset_type, ts);

CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id    INTEGER,
    symbol      TEXT NOT NULL,
    price       REAL NOT NULL,
    message     TEXT NOT NULL,
    ts          TEXT NOT NULL
);
"""


def _dt(value: str | None) -> datetime | None:
    return datetime.fromisoformat(value) if value else None


class Storage:
    """Thin repository layer over a SQLite database."""

    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).expanduser().parent.mkdir(parents=True, exist_ok=True)
            self.path = str(Path(self.path).expanduser())
        self._conn = sqlite3.connect(self.path)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    # -- lifecycle -------------------------------------------------------
    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> Storage:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        try:
            yield self._conn
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise

    # -- alerts ----------------------------------------------------------
    @staticmethod
    def _alert_from_row(row: sqlite3.Row) -> Alert:
        return Alert(
            id=row["id"],
            symbol=row["symbol"],
            asset_type=row["asset_type"],
            condition=row["condition"],
            threshold=row["threshold"],
            window_minutes=row["window_minutes"],
            cooldown_minutes=row["cooldown_minutes"],
            active=bool(row["active"]),
            last_triggered=_dt(row["last_triggered"]),
            created_at=datetime.fromisoformat(row["created_at"]),
        )

    def add_alert(self, alert: Alert) -> Alert:
        with self._tx() as c:
            cur = c.execute(
                "INSERT INTO alerts (symbol, asset_type, condition, threshold, window_minutes,"
                " cooldown_minutes, active, created_at) VALUES (?,?,?,?,?,?,?,?)",
                (
                    alert.symbol,
                    alert.asset_type,
                    alert.condition,
                    alert.threshold,
                    alert.window_minutes,
                    alert.cooldown_minutes,
                    int(alert.active),
                    alert.created_at.isoformat(),
                ),
            )
        alert.id = cur.lastrowid
        return alert

    def list_alerts(self, active_only: bool = False) -> list[Alert]:
        sql = "SELECT * FROM alerts"
        if active_only:
            sql += " WHERE active = 1"
        sql += " ORDER BY id"
        return [self._alert_from_row(r) for r in self._conn.execute(sql)]

    def get_alert(self, alert_id: int) -> Alert | None:
        row = self._conn.execute("SELECT * FROM alerts WHERE id = ?", (alert_id,)).fetchone()
        return self._alert_from_row(row) if row else None

    def remove_alert(self, alert_id: int) -> bool:
        with self._tx() as c:
            cur = c.execute("DELETE FROM alerts WHERE id = ?", (alert_id,))
        return cur.rowcount > 0

    def set_active(self, alert_id: int, active: bool) -> bool:
        with self._tx() as c:
            cur = c.execute("UPDATE alerts SET active = ? WHERE id = ?", (int(active), alert_id))
        return cur.rowcount > 0

    def mark_triggered(self, alert_id: int, when: datetime) -> None:
        with self._tx() as c:
            c.execute("UPDATE alerts SET last_triggered = ? WHERE id = ?", (when.isoformat(), alert_id))

    # -- prices ----------------------------------------------------------
    def record_price(self, quote: Quote) -> None:
        with self._tx() as c:
            c.execute(
                "INSERT INTO prices (symbol, asset_type, price, currency, source, ts)"
                " VALUES (?,?,?,?,?,?)",
                (
                    quote.symbol,
                    quote.asset_type,
                    quote.price,
                    quote.currency,
                    quote.source,
                    quote.timestamp.isoformat(),
                ),
            )

    def reference_price(
        self, symbol: str, asset_type: str, since: datetime, before: datetime
    ) -> float | None:
        """Oldest recorded price with ``since <= ts < before`` (None if there is none)."""
        row = self._conn.execute(
            "SELECT price FROM prices WHERE symbol = ? AND asset_type = ? AND ts >= ? AND ts < ?"
            " ORDER BY ts ASC LIMIT 1",
            (symbol, asset_type, since.isoformat(), before.isoformat()),
        ).fetchone()
        return row["price"] if row else None

    def price_history(self, symbol: str, asset_type: str | None = None, limit: int = 20) -> list[Quote]:
        sql = "SELECT * FROM prices WHERE symbol = ?"
        params: list[object] = [symbol.upper()]
        if asset_type:
            sql += " AND asset_type = ?"
            params.append(asset_type)
        sql += " ORDER BY ts DESC LIMIT ?"
        params.append(limit)
        return [
            Quote(
                symbol=r["symbol"],
                asset_type=r["asset_type"],
                price=r["price"],
                currency=r["currency"],
                timestamp=datetime.fromisoformat(r["ts"]),
                source=r["source"],
            )
            for r in self._conn.execute(sql, params)
        ]

    def prune_prices(self, retention_days: int, now: datetime | None = None) -> int:
        cutoff = (now or utcnow()) - timedelta(days=retention_days)
        with self._tx() as c:
            cur = c.execute("DELETE FROM prices WHERE ts < ?", (cutoff.isoformat(),))
        return cur.rowcount

    # -- events ----------------------------------------------------------
    def record_event(self, alert_id: int | None, symbol: str, price: float, message: str, ts: datetime) -> None:
        with self._tx() as c:
            c.execute(
                "INSERT INTO events (alert_id, symbol, price, message, ts) VALUES (?,?,?,?,?)",
                (alert_id, symbol, price, message, ts.isoformat()),
            )

    def list_events(self, limit: int = 20) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM events ORDER BY ts DESC, id DESC LIMIT ?", (limit,))
        return [dict(r) for r in rows]
