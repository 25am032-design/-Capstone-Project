"""Notifier abstraction."""

from __future__ import annotations

from abc import ABC, abstractmethod


class NotifierError(Exception):
    """Raised when a notification could not be delivered."""


class Notifier(ABC):
    name: str = "notifier"

    @abstractmethod
    def send(self, title: str, message: str) -> None:
        """Deliver a notification or raise :class:`NotifierError`."""
