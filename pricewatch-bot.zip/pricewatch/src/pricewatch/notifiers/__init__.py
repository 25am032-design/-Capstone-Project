"""Notification channels and a factory that builds them from configuration."""

from __future__ import annotations

import logging
from typing import Any

from pricewatch.notifiers.base import Notifier, NotifierError
from pricewatch.notifiers.channels import (
    ConsoleNotifier,
    EmailNotifier,
    TelegramNotifier,
    WebhookNotifier,
)

log = logging.getLogger(__name__)

__all__ = [
    "ConsoleNotifier",
    "EmailNotifier",
    "Notifier",
    "NotifierError",
    "TelegramNotifier",
    "WebhookNotifier",
    "build_notifiers",
]


def build_notifiers(settings: dict[str, dict[str, Any]]) -> list[Notifier]:
    """Instantiate every enabled notifier. Misconfigured channels are skipped with a warning."""
    notifiers: list[Notifier] = []
    for name, opts in settings.items():
        if not opts.get("enabled", False):
            continue
        try:
            if name == "console":
                notifiers.append(ConsoleNotifier())
            elif name == "telegram":
                notifiers.append(TelegramNotifier(opts.get("bot_token", ""), opts.get("chat_id", "")))
            elif name == "webhook":
                notifiers.append(WebhookNotifier(opts.get("url", "")))
            elif name == "email":
                notifiers.append(
                    EmailNotifier(
                        smtp_host=opts.get("smtp_host", ""),
                        smtp_port=int(opts.get("smtp_port", 587)),
                        username=opts.get("username", ""),
                        password=opts.get("password", ""),
                        sender=opts.get("sender", ""),
                        recipients=list(opts.get("recipients", [])),
                    )
                )
            else:
                log.warning("unknown notifier %r in config - ignored", name)
        except ValueError as exc:
            log.warning("notifier %r disabled: %s", name, exc)
    return notifiers
