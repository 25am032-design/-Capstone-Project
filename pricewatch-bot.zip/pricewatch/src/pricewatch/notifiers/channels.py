"""Concrete notification channels: console, Telegram, e-mail and generic webhook."""

from __future__ import annotations

import smtplib
import ssl
from email.message import EmailMessage

import requests

from pricewatch.notifiers.base import Notifier, NotifierError


class ConsoleNotifier(Notifier):
    name = "console"

    def send(self, title: str, message: str) -> None:
        print(f"\U0001f514 {title}\n   {message}", flush=True)


class TelegramNotifier(Notifier):
    name = "telegram"

    def __init__(self, bot_token: str, chat_id: str, session: requests.Session | None = None) -> None:
        if not bot_token or not chat_id:
            raise ValueError("telegram notifier needs bot_token and chat_id")
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.session = session or requests.Session()

    def send(self, title: str, message: str) -> None:
        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        try:
            resp = self.session.post(
                url, json={"chat_id": self.chat_id, "text": f"{title}\n{message}"}, timeout=10
            )
            resp.raise_for_status()
        except requests.RequestException as exc:
            # Do not leak the bot token (it is part of the URL) in error messages.
            raise NotifierError(f"telegram delivery failed: {type(exc).__name__}") from None


class WebhookNotifier(Notifier):
    """POSTs ``{"text": ..., "title": ..., "message": ...}`` (works with Slack & Discord)."""

    name = "webhook"

    def __init__(self, url: str, session: requests.Session | None = None) -> None:
        if not url:
            raise ValueError("webhook notifier needs a url")
        self.url = url
        self.session = session or requests.Session()

    def send(self, title: str, message: str) -> None:
        payload = {
            "title": title,
            "message": message,
            "text": f"{title}\n{message}",  # Slack
            "content": f"{title}\n{message}",  # Discord
        }
        try:
            resp = self.session.post(self.url, json=payload, timeout=10)
            resp.raise_for_status()
        except requests.RequestException as exc:
            raise NotifierError(f"webhook delivery failed: {type(exc).__name__}") from None


class EmailNotifier(Notifier):
    name = "email"

    def __init__(
        self,
        smtp_host: str,
        smtp_port: int,
        username: str,
        password: str,
        sender: str,
        recipients: list[str],
    ) -> None:
        if not (smtp_host and sender and recipients):
            raise ValueError("email notifier needs smtp_host, sender and recipients")
        self.smtp_host = smtp_host
        self.smtp_port = int(smtp_port)
        self.username = username
        self.password = password
        self.sender = sender
        self.recipients = list(recipients)

    def send(self, title: str, message: str) -> None:
        msg = EmailMessage()
        msg["Subject"] = title
        msg["From"] = self.sender
        msg["To"] = ", ".join(self.recipients)
        msg.set_content(message)
        try:
            with smtplib.SMTP(self.smtp_host, self.smtp_port, timeout=15) as smtp:
                smtp.starttls(context=ssl.create_default_context())
                if self.username:
                    smtp.login(self.username, self.password)
                smtp.send_message(msg)
        except (smtplib.SMTPException, OSError) as exc:
            raise NotifierError(f"email delivery failed: {type(exc).__name__}") from None
