"""Configuration loading (TOML file + environment overrides)."""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

DEFAULT_HOME = Path.home() / ".pricewatch"

SAMPLE_CONFIG = """\
# pricewatch configuration
# Values may reference environment variables, e.g. "${TELEGRAM_BOT_TOKEN}".

[general]
# db_path = "~/.pricewatch/pricewatch.db"
interval_seconds = 60      # how often `pricewatch run` checks prices
retention_days = 30        # price history older than this is pruned
mock = false               # true = use a simulated price feed (offline demo)
log_level = "INFO"
# log_file = "~/.pricewatch/pricewatch.log"

[notifiers.console]
enabled = true

[notifiers.telegram]
enabled = false
bot_token = "${TELEGRAM_BOT_TOKEN}"
chat_id = "${TELEGRAM_CHAT_ID}"

[notifiers.email]
enabled = false
smtp_host = "smtp.gmail.com"
smtp_port = 587
username = "${SMTP_USERNAME}"
password = "${SMTP_PASSWORD}"
sender = "${SMTP_USERNAME}"
recipients = ["you@example.com"]

[notifiers.webhook]          # Slack / Discord / any endpoint accepting JSON
enabled = false
url = "${WEBHOOK_URL}"
"""


@dataclass
class Config:
    db_path: Path = field(default_factory=lambda: DEFAULT_HOME / "pricewatch.db")
    interval_seconds: int = 60
    retention_days: int = 30
    mock: bool = False
    log_level: str = "INFO"
    log_file: Path | None = None
    notifiers: dict[str, dict[str, Any]] = field(default_factory=lambda: {"console": {"enabled": True}})


def _expand(value: Any) -> Any:
    """Recursively expand ``${VAR}`` / ``$VAR`` and ``~`` inside strings."""
    if isinstance(value, str):
        return os.path.expandvars(value)
    if isinstance(value, list):
        return [_expand(v) for v in value]
    if isinstance(value, dict):
        return {k: _expand(v) for k, v in value.items()}
    return value


def _truthy(text: str) -> bool:
    return text.strip().lower() in {"1", "true", "yes", "on"}


def find_config_file(explicit: str | os.PathLike[str] | None = None) -> Path | None:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit))
    elif env := os.environ.get("PRICEWATCH_CONFIG"):
        candidates.append(Path(env))
    else:
        candidates += [Path.cwd() / "pricewatch.toml", DEFAULT_HOME / "config.toml"]
    for path in candidates:
        path = path.expanduser()
        if path.is_file():
            return path
    if explicit:
        raise FileNotFoundError(f"config file not found: {explicit}")
    return None


def load_config(explicit: str | os.PathLike[str] | None = None) -> Config:
    """Load configuration from TOML (if present) and apply env overrides."""
    cfg = Config()
    path = find_config_file(explicit)
    if path:
        with path.open("rb") as fh:
            raw = _expand(tomllib.load(fh))
        general = raw.get("general", {})
        if "db_path" in general:
            cfg.db_path = Path(general["db_path"]).expanduser()
        cfg.interval_seconds = int(general.get("interval_seconds", cfg.interval_seconds))
        cfg.retention_days = int(general.get("retention_days", cfg.retention_days))
        cfg.mock = bool(general.get("mock", cfg.mock))
        cfg.log_level = str(general.get("log_level", cfg.log_level)).upper()
        if general.get("log_file"):
            cfg.log_file = Path(general["log_file"]).expanduser()
        if "notifiers" in raw:
            cfg.notifiers = raw["notifiers"]

    # Environment overrides
    if db := os.environ.get("PRICEWATCH_DB"):
        cfg.db_path = Path(db).expanduser()
    if mock := os.environ.get("PRICEWATCH_MOCK"):
        cfg.mock = _truthy(mock)
    if interval := os.environ.get("PRICEWATCH_INTERVAL"):
        cfg.interval_seconds = int(interval)

    if cfg.interval_seconds < 1:
        raise ValueError("interval_seconds must be at least 1")
    return cfg
