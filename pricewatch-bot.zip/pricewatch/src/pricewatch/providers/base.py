"""Provider abstraction: anything that can turn symbols into quotes."""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from collections.abc import Sequence
from typing import Any

import requests

from pricewatch.models import Quote

log = logging.getLogger(__name__)

USER_AGENT = "pricewatch-bot/1.0 (+https://github.com/your-username/pricewatch-bot)"


class ProviderError(Exception):
    """Raised when a price source cannot be reached or returns unusable data."""


class Provider(ABC):
    """Base class for price providers."""

    name: str = "provider"
    asset_type: str = ""

    @abstractmethod
    def fetch(self, symbols: Sequence[str]) -> dict[str, Quote]:
        """Return a ``{SYMBOL: Quote}`` map. Unknown symbols are simply omitted.

        Raises :class:`ProviderError` if the source is entirely unavailable.
        """


def get_json(
    session: requests.Session,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    retries: int = 3,
    backoff: float = 1.0,
    timeout: float = 10.0,
    sleep=time.sleep,
) -> Any:
    """GET ``url`` and decode JSON, retrying transient failures with exponential backoff."""
    last_error: Exception | None = None
    for attempt in range(1, retries + 1):
        try:
            resp = session.get(
                url,
                params=params,
                headers={"User-Agent": USER_AGENT, **(headers or {})},
                timeout=timeout,
            )
            if resp.status_code == 429 or resp.status_code >= 500:
                retry_after = resp.headers.get("Retry-After", "")
                delay = float(retry_after) if retry_after.isdigit() else backoff * 2 ** (attempt - 1)
                last_error = ProviderError(f"HTTP {resp.status_code} from {url}")
                log.warning("%s (attempt %d/%d), retrying in %.1fs", last_error, attempt, retries, delay)
                if attempt < retries:
                    sleep(delay)
                continue
            if 400 <= resp.status_code < 500:  # client error: retrying will not help
                raise ProviderError(f"HTTP {resp.status_code} from {url}")
            resp.raise_for_status()
            return resp.json()
        except (requests.RequestException, ValueError) as exc:
            last_error = exc
            log.warning("request to %s failed (attempt %d/%d): %s", url, attempt, retries, exc)
            if attempt < retries:
                sleep(backoff * 2 ** (attempt - 1))
    raise ProviderError(f"giving up on {url}: {last_error}")
