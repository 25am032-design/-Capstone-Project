"""Offline simulated price feed for demos, development and tests.

Prices follow a deterministic sine wave (per symbol) plus small noise, so alerts
fire predictably without any network access.
"""

from __future__ import annotations

import math
import random
import zlib
from collections.abc import Callable, Sequence
from datetime import datetime

from pricewatch.models import Quote, utcnow
from pricewatch.providers.base import Provider


class MockProvider(Provider):
    name = "mock"

    def __init__(
        self,
        asset_type: str,
        clock: Callable[[], datetime] = utcnow,
        amplitude: float = 0.06,
        period_seconds: float = 300.0,
    ) -> None:
        self.asset_type = asset_type
        self.clock = clock
        self.amplitude = amplitude
        self.period_seconds = period_seconds

    def base_price(self, symbol: str) -> float:
        seed = zlib.crc32(symbol.upper().encode())
        rng = random.Random(seed)
        return round(rng.uniform(150, 450), 2) if self.asset_type == "stock" else round(
            rng.uniform(1_000, 60_000), 2
        )

    def fetch(self, symbols: Sequence[str]) -> dict[str, Quote]:
        now = self.clock()
        t = now.timestamp()
        quotes: dict[str, Quote] = {}
        for sym in symbols:
            sym = sym.upper()
            phase = (zlib.crc32(sym.encode()) % 360) * math.pi / 180
            wave = math.sin(2 * math.pi * t / self.period_seconds + phase)
            noise = random.Random(f"{sym}:{int(t // 5)}").uniform(-0.002, 0.002)
            price = self.base_price(sym) * (1 + self.amplitude * wave + noise)
            quotes[sym] = Quote(
                symbol=sym,
                asset_type=self.asset_type,
                price=round(price, 2),
                currency="USD",
                timestamp=now,
                source=self.name,
            )
        return quotes
