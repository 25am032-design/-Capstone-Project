"""Price providers and a factory that maps asset types to providers."""

from __future__ import annotations

from pricewatch.providers.base import Provider, ProviderError
from pricewatch.providers.coingecko import CoinGeckoProvider
from pricewatch.providers.mock import MockProvider
from pricewatch.providers.yahoo import YahooFinanceProvider

__all__ = [
    "CoinGeckoProvider",
    "MockProvider",
    "Provider",
    "ProviderError",
    "YahooFinanceProvider",
    "build_providers",
]


def build_providers(mock: bool = False) -> dict[str, Provider]:
    """Return ``{asset_type: provider}``. With ``mock=True`` no network is used."""
    if mock:
        return {"crypto": MockProvider("crypto"), "stock": MockProvider("stock")}
    return {"crypto": CoinGeckoProvider(), "stock": YahooFinanceProvider()}
