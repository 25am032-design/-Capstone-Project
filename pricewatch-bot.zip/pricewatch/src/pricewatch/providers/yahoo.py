"""Stock prices via Yahoo Finance's public chart endpoint (no API key required)."""

from __future__ import annotations

import logging
from collections.abc import Sequence

import requests

from pricewatch.models import Quote, utcnow
from pricewatch.providers.base import Provider, ProviderError, get_json

log = logging.getLogger(__name__)

API_URL = "https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"


class YahooFinanceProvider(Provider):
    name = "yahoo"
    asset_type = "stock"

    def __init__(self, session: requests.Session | None = None) -> None:
        self.session = session or requests.Session()

    def fetch(self, symbols: Sequence[str]) -> dict[str, Quote]:
        quotes: dict[str, Quote] = {}
        errors: list[str] = []
        for sym in symbols:
            sym = sym.upper()
            try:
                data = get_json(
                    self.session,
                    API_URL.format(symbol=sym),
                    params={"interval": "1m", "range": "1d"},
                )
                quotes[sym] = self._parse(sym, data)
            except ProviderError as exc:
                errors.append(f"{sym}: {exc}")
                log.warning("could not fetch %s: %s", sym, exc)
            except (KeyError, IndexError, TypeError, ValueError) as exc:
                errors.append(f"{sym}: unexpected response ({exc!r})")
                log.warning("unexpected Yahoo response for %s: %r", sym, exc)
        if symbols and not quotes and errors:
            raise ProviderError("; ".join(errors))
        return quotes

    def _parse(self, symbol: str, data: dict) -> Quote:
        result = data["chart"]["result"][0]
        meta = result["meta"]
        price = meta["regularMarketPrice"]
        if price is None:
            raise ValueError("no regularMarketPrice")
        return Quote(
            symbol=symbol,
            asset_type=self.asset_type,
            price=float(price),
            currency=str(meta.get("currency", "USD")),
            timestamp=utcnow(),
            source=self.name,
        )
