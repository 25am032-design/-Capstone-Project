"""Crypto prices via the public CoinGecko API (no API key required)."""

from __future__ import annotations

import os
from collections.abc import Sequence

import requests

from pricewatch.models import Quote, utcnow
from pricewatch.providers.base import Provider, get_json

API_URL = "https://api.coingecko.com/api/v3/simple/price"

# Common tickers -> CoinGecko ids. Anything else is treated as a CoinGecko id.
TICKER_TO_ID = {
    "BTC": "bitcoin",
    "ETH": "ethereum",
    "SOL": "solana",
    "BNB": "binancecoin",
    "XRP": "ripple",
    "ADA": "cardano",
    "DOGE": "dogecoin",
    "DOT": "polkadot",
    "LTC": "litecoin",
    "AVAX": "avalanche-2",
    "LINK": "chainlink",
    "MATIC": "matic-network",
    "TRX": "tron",
    "SHIB": "shiba-inu",
    "USDT": "tether",
}


def resolve_coin_id(symbol: str) -> str:
    return TICKER_TO_ID.get(symbol.upper(), symbol.lower())


class CoinGeckoProvider(Provider):
    name = "coingecko"
    asset_type = "crypto"

    def __init__(self, session: requests.Session | None = None, vs_currency: str = "usd") -> None:
        self.session = session or requests.Session()
        self.vs_currency = vs_currency.lower()

    def fetch(self, symbols: Sequence[str]) -> dict[str, Quote]:
        if not symbols:
            return {}
        ids = {sym.upper(): resolve_coin_id(sym) for sym in symbols}
        headers = {}
        if key := os.environ.get("COINGECKO_API_KEY"):
            headers["x-cg-demo-api-key"] = key
        data = get_json(
            self.session,
            API_URL,
            params={"ids": ",".join(sorted(set(ids.values()))), "vs_currencies": self.vs_currency},
            headers=headers,
        )
        now = utcnow()
        quotes: dict[str, Quote] = {}
        for sym, coin_id in ids.items():
            price = (data.get(coin_id) or {}).get(self.vs_currency)
            if price is None:
                continue
            quotes[sym] = Quote(
                symbol=sym,
                asset_type=self.asset_type,
                price=float(price),
                currency=self.vs_currency.upper(),
                timestamp=now,
                source=self.name,
            )
        return quotes
