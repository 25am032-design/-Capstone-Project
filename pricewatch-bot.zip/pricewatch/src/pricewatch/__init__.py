"""pricewatch - a crypto & stock price alert bot."""

__version__ = "1.0.0"
