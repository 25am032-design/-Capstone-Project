"""A small, dependency-free interval scheduler with graceful shutdown."""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable

log = logging.getLogger(__name__)


class Scheduler:
    """Run ``job`` every ``interval_seconds`` until stopped.

    * Drift-free: the next run is computed from the previous *scheduled* time.
    * Exceptions inside the job are logged and never kill the loop.
    * ``stop()`` is thread/signal-safe and interrupts the wait immediately.
    """

    def __init__(
        self,
        job: Callable[[], object],
        interval_seconds: float,
        *,
        run_immediately: bool = True,
        max_runs: int | None = None,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        if interval_seconds <= 0:
            raise ValueError("interval_seconds must be positive")
        self.job = job
        self.interval = interval_seconds
        self.run_immediately = run_immediately
        self.max_runs = max_runs
        self.runs = 0
        self._monotonic = monotonic
        self._stop = threading.Event()

    def stop(self) -> None:
        self._stop.set()

    @property
    def stopped(self) -> bool:
        return self._stop.is_set()

    def start(self) -> None:
        """Block and run the job on schedule until :meth:`stop` or ``max_runs`` is reached."""
        next_run = self._monotonic() + (0 if self.run_immediately else self.interval)
        while not self._stop.is_set():
            delay = max(0.0, next_run - self._monotonic())
            if self._stop.wait(delay):
                break
            self._run_once()
            if self.max_runs is not None and self.runs >= self.max_runs:
                break
            next_run += self.interval
            # If we fell far behind (e.g. laptop sleep), skip missed runs instead of bursting.
            now = self._monotonic()
            if next_run < now:
                next_run = now + self.interval

    def _run_once(self) -> None:
        self.runs += 1
        try:
            self.job()
        except Exception:
            log.exception("scheduled job failed (run #%d)", self.runs)
