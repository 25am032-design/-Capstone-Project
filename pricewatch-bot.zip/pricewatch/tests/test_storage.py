from datetime import timedelta

from conftest import T0, make_quote

from pricewatch.models import Alert


def test_alert_crud(db):
    a = db.add_alert(Alert("btc", "crypto", "below", 20_000, cooldown_minutes=5))
    assert a.id == 1
    fetched = db.get_alert(1)
    assert fetched.symbol == "BTC" and fetched.condition == "below" and fetched.cooldown_minutes == 5

    assert db.set_active(1, False)
    assert db.list_alerts(active_only=True) == []
    assert len(db.list_alerts()) == 1

    assert db.remove_alert(1)
    assert not db.remove_alert(1)


def test_price_history_reference_and_prune(db):
    for i, price in enumerate([100, 101, 102]):
        db.record_price(make_quote(price=price, ts=T0 + timedelta(minutes=i * 10)))

    history = db.price_history("btc", limit=2)
    assert [q.price for q in history] == [102, 101]  # newest first

    ref = db.reference_price("BTC", "crypto", since=T0 + timedelta(minutes=5), before=T0 + timedelta(minutes=30))
    assert ref == 101
    assert db.reference_price("BTC", "crypto", since=T0 + timedelta(hours=1), before=T0 + timedelta(hours=2)) is None

    assert db.prune_prices(retention_days=1, now=T0 + timedelta(days=3)) == 3
    assert db.price_history("BTC") == []


def test_events(db):
    db.record_event(1, "BTC", 123.0, "hello", T0)
    db.record_event(None, "ETH", 5.0, "later", T0 + timedelta(minutes=1))
    events = db.list_events()
    assert [e["message"] for e in events] == ["later", "hello"]
