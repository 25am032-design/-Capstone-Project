from datetime import timedelta

import pytest
from conftest import T0, make_quote

from pricewatch.engine import AlertEngine, evaluate_alert
from pricewatch.models import Alert
from pricewatch.providers.base import Provider, ProviderError


class FakeProvider(Provider):
    name = "fake"

    def __init__(self, asset_type, prices=None, fail=False):
        self.asset_type = asset_type
        self.prices = prices or {}
        self.fail = fail
        self.now = T0

    def fetch(self, symbols):
        if self.fail:
            raise ProviderError("boom")
        return {
            s: make_quote(s, self.prices[s], self.asset_type, self.now) for s in symbols if s in self.prices
        }


class Recorder:
    name = "recorder"

    def __init__(self):
        self.sent = []

    def send(self, title, message):
        self.sent.append((title, message))


# ---------------------------------------------------------------- models
def test_alert_normalizes_and_validates():
    assert Alert("btc", "crypto", "above", 1).symbol == "BTC"
    with pytest.raises(ValueError):
        Alert("btc", "forex", "above", 1)
    with pytest.raises(ValueError):
        Alert("btc", "crypto", "sideways", 1)
    with pytest.raises(ValueError):
        Alert("btc", "crypto", "above", 0)


# ---------------------------------------------------------------- evaluate_alert
def test_above_and_below():
    above = Alert("BTC", "crypto", "above", 100)
    below = Alert("BTC", "crypto", "below", 100)
    assert evaluate_alert(above, make_quote(price=100), None, T0)
    assert not evaluate_alert(above, make_quote(price=99.99), None, T0)
    assert evaluate_alert(below, make_quote(price=100), None, T0)
    assert not evaluate_alert(below, make_quote(price=100.01), None, T0)


def test_rise_and_drop_use_reference_price():
    rise = Alert("BTC", "crypto", "rise", 5)
    drop = Alert("BTC", "crypto", "drop", 5)
    assert evaluate_alert(rise, make_quote(price=105), 100, T0)
    assert not evaluate_alert(rise, make_quote(price=104), 100, T0)
    assert evaluate_alert(drop, make_quote(price=95), 100, T0)
    assert not evaluate_alert(drop, make_quote(price=96), 100, T0)
    assert not evaluate_alert(rise, make_quote(price=200), None, T0)  # no history yet


def test_cooldown_and_paused():
    alert = Alert("BTC", "crypto", "above", 10, cooldown_minutes=30)
    alert.last_triggered = T0 - timedelta(minutes=10)
    assert not evaluate_alert(alert, make_quote(price=50), None, T0)
    assert evaluate_alert(alert, make_quote(price=50), None, T0 + timedelta(minutes=21))
    alert.active = False
    assert not evaluate_alert(alert, make_quote(price=50), None, T0 + timedelta(hours=5))


# ---------------------------------------------------------------- engine cycle
def build_engine(db, crypto, stock=None, notifier=None, clock=lambda: T0):
    providers = {"crypto": crypto, "stock": stock or FakeProvider("stock")}
    return AlertEngine(db, providers, [notifier] if notifier else [], clock=clock)


def test_cycle_fires_notifies_and_respects_cooldown(db):
    db.add_alert(Alert("BTC", "crypto", "above", 100))
    rec = Recorder()
    engine = build_engine(db, FakeProvider("crypto", {"BTC": 150}), notifier=rec)

    first = engine.run_cycle()
    assert (first.quotes_fetched, first.alerts_checked, first.alerts_triggered) == (1, 1, 1)
    assert len(rec.sent) == 1 and "BTC" in rec.sent[0][1]
    assert db.list_events()[0]["symbol"] == "BTC"
    assert db.list_alerts()[0].last_triggered is not None

    second = engine.run_cycle()  # still inside cooldown
    assert second.alerts_triggered == 0 and len(rec.sent) == 1


def test_cycle_percentage_alert_uses_history(db):
    db.add_alert(Alert("ETH", "crypto", "rise", 5, window_minutes=60))
    provider = FakeProvider("crypto", {"ETH": 100.0})
    rec = Recorder()
    clock = {"now": T0}
    engine = build_engine(db, provider, notifier=rec, clock=lambda: clock["now"])

    assert engine.run_cycle().alerts_triggered == 0  # baseline sample only
    clock["now"] = provider.now = T0 + timedelta(minutes=10)
    provider.prices["ETH"] = 106.0
    assert engine.run_cycle().alerts_triggered == 1
    assert "rose" in rec.sent[0][1]


def test_provider_failure_is_reported_not_raised(db):
    db.add_alert(Alert("BTC", "crypto", "above", 1))
    engine = build_engine(db, FakeProvider("crypto", fail=True))
    result = engine.run_cycle()
    assert result.alerts_checked == 0 and result.errors


def test_missing_symbol_is_reported(db):
    db.add_alert(Alert("NOPE", "crypto", "above", 1))
    result = build_engine(db, FakeProvider("crypto", {})).run_cycle()
    assert any("NOPE" in e for e in result.errors)


def test_broken_notifier_does_not_block_others(db):
    class Broken:
        name = "broken"

        def send(self, *_):
            raise RuntimeError("down")

    db.add_alert(Alert("BTC", "crypto", "above", 1))
    rec = Recorder()
    engine = AlertEngine(db, {"crypto": FakeProvider("crypto", {"BTC": 5})}, [Broken(), rec], clock=lambda: T0)
    assert engine.run_cycle().alerts_triggered == 1
    assert len(rec.sent) == 1
