import threading

import pytest

from pricewatch.config import load_config
from pricewatch.notifiers import NotifierError, TelegramNotifier, WebhookNotifier, build_notifiers
from pricewatch.scheduler import Scheduler


# ---------------------------------------------------------------- scheduler
def test_scheduler_runs_max_runs_and_survives_errors():
    calls = []

    def job():
        calls.append(1)
        if len(calls) == 1:
            raise RuntimeError("first run explodes")

    s = Scheduler(job, 0.01, max_runs=3)
    s.start()
    assert s.runs == 3 and len(calls) == 3


def test_scheduler_stop_interrupts_wait():
    s = Scheduler(lambda: None, 60)
    t = threading.Thread(target=s.start)
    t.start()
    while s.runs < 1:
        pass
    s.stop()
    t.join(timeout=2)
    assert not t.is_alive()


def test_scheduler_rejects_bad_interval():
    with pytest.raises(ValueError):
        Scheduler(lambda: None, 0)


# ---------------------------------------------------------------- notifiers
class FakePoster:
    def __init__(self, fail=False):
        self.fail = fail
        self.calls = []

    def post(self, url, **kwargs):
        import requests

        self.calls.append((url, kwargs))
        if self.fail:
            raise requests.ConnectionError("secret-token-in-url")

        class R:
            def raise_for_status(self):
                pass

        return R()


def test_telegram_and_webhook_payloads():
    poster = FakePoster()
    TelegramNotifier("TOKEN", "42", poster).send("t", "m")
    assert poster.calls[0][0].endswith("botTOKEN/sendMessage")
    assert poster.calls[0][1]["json"]["chat_id"] == "42"

    WebhookNotifier("http://hook", poster).send("t", "m")
    assert poster.calls[1][1]["json"]["text"] == "t\nm"


def test_notifier_errors_do_not_leak_token():
    with pytest.raises(NotifierError) as exc:
        TelegramNotifier("SECRET", "1", FakePoster(fail=True)).send("t", "m")
    assert "SECRET" not in str(exc.value) and "secret-token" not in str(exc.value)


def test_build_notifiers_skips_disabled_and_misconfigured():
    built = build_notifiers(
        {
            "console": {"enabled": True},
            "telegram": {"enabled": True, "bot_token": "", "chat_id": ""},  # misconfigured
            "webhook": {"enabled": False, "url": "http://x"},
            "bogus": {"enabled": True},
        }
    )
    assert [n.name for n in built] == ["console"]


# ---------------------------------------------------------------- config
def test_config_file_env_expansion_and_overrides(tmp_path, monkeypatch):
    monkeypatch.setenv("MY_TOKEN", "abc123")
    monkeypatch.delenv("PRICEWATCH_DB", raising=False)
    cfg_file = tmp_path / "cfg.toml"
    cfg_file.write_text(
        '[general]\ninterval_seconds = 15\nmock = true\n'
        f'db_path = "{tmp_path / "x.db"}"\n'
        '[notifiers.telegram]\nenabled = true\nbot_token = "${MY_TOKEN}"\nchat_id = "7"\n'
    )
    cfg = load_config(cfg_file)
    assert cfg.interval_seconds == 15 and cfg.mock is True
    assert cfg.notifiers["telegram"]["bot_token"] == "abc123"

    monkeypatch.setenv("PRICEWATCH_INTERVAL", "99")
    assert load_config(cfg_file).interval_seconds == 99


def test_missing_explicit_config_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_config(tmp_path / "nope.toml")
