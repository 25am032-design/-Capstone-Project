import pytest
import requests

from pricewatch.providers import MockProvider, ProviderError
from pricewatch.providers.base import get_json
from pricewatch.providers.coingecko import CoinGeckoProvider, resolve_coin_id
from pricewatch.providers.yahoo import YahooFinanceProvider


class FakeResponse:
    def __init__(self, status=200, payload=None, headers=None):
        self.status_code = status
        self._payload = payload
        self.headers = headers or {}

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"{self.status_code}")

    def json(self):
        if self._payload is None:
            raise ValueError("no json")
        return self._payload


class FakeSession:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []

    def get(self, url, **kwargs):
        self.calls.append((url, kwargs))
        item = self.responses.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


def test_get_json_retries_then_succeeds():
    session = FakeSession(FakeResponse(500), requests.ConnectionError("x"), FakeResponse(200, {"ok": 1}))
    sleeps = []
    assert get_json(session, "http://x", sleep=sleeps.append) == {"ok": 1}
    assert len(session.calls) == 3 and sleeps == [1.0, 2.0]


def test_get_json_gives_up():
    session = FakeSession(*[FakeResponse(503)] * 3)
    with pytest.raises(ProviderError):
        get_json(session, "http://x", sleep=lambda _: None)


def test_get_json_does_not_retry_client_errors():
    session = FakeSession(FakeResponse(404, {}))
    with pytest.raises(ProviderError):
        get_json(session, "http://x", sleep=lambda _: None)
    assert len(session.calls) == 1


def test_coingecko_parses_and_maps_tickers():
    assert resolve_coin_id("btc") == "bitcoin"
    assert resolve_coin_id("Some-Coin") == "some-coin"
    session = FakeSession(FakeResponse(200, {"bitcoin": {"usd": 65000.5}, "ethereum": {"usd": 3200}}))
    quotes = CoinGeckoProvider(session).fetch(["BTC", "ETH", "UNKNOWN"])
    assert quotes["BTC"].price == 65000.5 and quotes["BTC"].currency == "USD"
    assert "UNKNOWN" not in quotes
    assert session.calls[0][1]["params"]["ids"] == "bitcoin,ethereum,unknown"


def yahoo_payload(price, currency="USD"):
    return {"chart": {"result": [{"meta": {"regularMarketPrice": price, "currency": currency}}]}}


def test_yahoo_parses_and_isolates_failures():
    session = FakeSession(FakeResponse(200, yahoo_payload(190.25)), FakeResponse(404, {}))
    quotes = YahooFinanceProvider(session).fetch(["AAPL", "BAD"])
    assert set(quotes) == {"AAPL"} and quotes["AAPL"].price == 190.25


def test_yahoo_all_failed_raises():
    session = FakeSession(FakeResponse(200, {"chart": {"result": None}}))
    with pytest.raises(ProviderError):
        YahooFinanceProvider(session).fetch(["AAPL"])


def test_mock_provider_is_deterministic_and_bounded():
    from conftest import T0

    p = MockProvider("stock", clock=lambda: T0)
    a, b = p.fetch(["AAPL"])["AAPL"], p.fetch(["AAPL"])["AAPL"]
    assert a.price == b.price
    base = p.base_price("AAPL")
    assert abs(a.price - base) / base < 0.07
