import pytest

from pricewatch.cli import main


@pytest.fixture()
def run(tmp_path, monkeypatch, capsys):
    monkeypatch.delenv("PRICEWATCH_CONFIG", raising=False)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("HOME", str(tmp_path))  # keep ~/.pricewatch out of the real home
    db = str(tmp_path / "t.db")

    def _run(*argv):
        code = main(["--db", db, "--mock", *argv])
        out = capsys.readouterr()
        return code, out.out, out.err

    return _run


def test_add_list_pause_resume_remove(run):
    code, out, _ = run("add", "btc", "--above", "1")
    assert code == 0 and "Created alert #1" in out

    code, out, _ = run("list")
    assert "BTC" in out and "active" in out

    assert run("pause", "1")[0] == 0
    assert "No alerts" in run("list")[1]
    assert "paused" in run("list", "--all")[1]
    assert run("resume", "1")[0] == 0
    assert run("remove", "1")[0] == 0
    assert run("remove", "1")[0] == 1  # already gone


def test_add_validation(run):
    code, _, err = run("add", "btc", "--above", "-5")
    assert code == 2 and "threshold" in err


def test_check_history_events_flow(run):
    run("add", "BTC", "--above", "1")  # mock price is always far above $1
    run("add", "AAPL", "--type", "stock", "--below", "1")  # never fires
    code, out, _ = run("check")
    assert code == 0 and "2 alert(s)" in out and "1 triggered" in out

    assert "BTC" in run("history", "BTC")[1]
    assert "above" in run("events")[1]


def test_price_command(run):
    code, out, _ = run("price", "ETH")
    assert code == 0 and "ETH:" in out and "[mock]" in out


def test_run_with_max_runs(run):
    run("add", "SOL", "--above", "1")
    code, out, _ = run("run", "--interval", "1", "--max-runs", "2")
    assert code == 0
    assert "Price alert #1: SOL" in out


def test_init_writes_sample_config(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    target = tmp_path / "cfg.toml"
    assert main(["init", "--path", str(target)]) == 0
    assert "[notifiers.telegram]" in target.read_text()
    assert main(["init", "--path", str(target)]) == 1  # refuses to overwrite


def test_test_notify_defaults_to_console(run):
    code, out, _ = run("test-notify")
    assert code == 0 and "[ok]   console" in out
