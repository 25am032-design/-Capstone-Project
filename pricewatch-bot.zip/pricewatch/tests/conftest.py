from datetime import UTC, datetime

import pytest

from pricewatch.models import Quote
from pricewatch.storage import Storage

T0 = datetime(2026, 1, 1, 12, 0, tzinfo=UTC)


@pytest.fixture()
def db():
    with Storage(":memory:") as storage:
        yield storage


def make_quote(symbol="BTC", price=100.0, asset_type="crypto", ts=T0):
    return Quote(symbol=symbol, asset_type=asset_type, price=price, currency="USD", timestamp=ts, source="test")
