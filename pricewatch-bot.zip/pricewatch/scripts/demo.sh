#!/usr/bin/env bash
# End-to-end demo using the offline simulated feed. Record this for your video walkthrough.
set -euo pipefail

DB="$(mktemp -d)/demo.db"
PW="pricewatch --db $DB --mock"

echo "### 1. Create alerts"
$PW add BTC  --above 1000 --cooldown 1
$PW add ETH  --drop 3 --window 5
$PW add AAPL --type stock --below 1000 --cooldown 1
$PW list

echo; echo "### 2. Run the scheduler for 3 cycles (5s interval)"
$PW run --interval 5 --max-runs 3

echo; echo "### 3. Inspect results"
$PW events
$PW history BTC -n 5
